package com.jforu.proxies;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.VpnService;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import com.jforu.proxies.util.Profile;
import com.jforu.proxies.util.ProfileManager;
import com.jforu.proxies.util.Utility;
import com.jforu.proxies.BuildConfig;

/** SocksVpnPlugin مع حماية "reply already submitted" */
public class SocksVpnPlugin implements FlutterPlugin, MethodChannel.MethodCallHandler {

    /** للسماح لـ MainActivity بطلب إذن VPN */
    public interface PermissionRequester { void onRequestPermission(Map<String,Object> args); }
    private static PermissionRequester permissionRequester;

    private static final String TAG    = SocksVpnPlugin.class.getSimpleName();
    private static final boolean DEBUG = BuildConfig.DEBUG;

    private MethodChannel  channel;
    private Context        context;
    private ProfileManager manager;

    public SocksVpnPlugin() {}
    public SocksVpnPlugin(PermissionRequester r) { permissionRequester = r; }

    /* -------- FlutterPlugin -------- */
    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding binding) {
        context  = binding.getApplicationContext();
        channel  = new MethodChannel(binding.getBinaryMessenger(), "socks_vpn");
        channel.setMethodCallHandler(this);
        manager  = new ProfileManager(context);
    }
    @Override public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
        if (channel != null) channel.setMethodCallHandler(null);
    }

    /* -------- MethodChannel -------- */
    @Override @SuppressWarnings("unchecked")
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        switch (call.method) {
            case "start":
                Map<String,Object> args = (Map<String,Object>) call.arguments;
                if (args == null) { result.error("ARGS","null",null); return; }
                startVpn(args, result);
                break;

            case "stop": stopVpn(result); break;
            default:      result.notImplemented();
        }
    }

    /* =====================  START  ===================== */
    private void startVpn(Map<String,Object> a, MethodChannel.Result result) {
        Intent prep = VpnService.prepare(context);
        if (prep != null) {
            if (permissionRequester != null) permissionRequester.onRequestPermission(a);
            result.error("PERMISSION","vpn-permission-required",null);
            return;
        }
        startVpnDirect(context, a);
        result.success(true);
    }

    public static void startVpnDirect(Context ctx, Map<String,Object> a) {
        ProfileManager mgr = new ProfileManager(ctx);
        String name   = (String) a.getOrDefault("name", "Flutter-Profile");
        String server = (String) a.getOrDefault("server", "127.0.0.1");
        int    port   = ((Number)a.getOrDefault("port",1080)).intValue();
        String user   = (String) a.getOrDefault("username","");
        String pass   = (String) a.getOrDefault("password","");

        Profile p = mgr.addProfile(name);
        if (p == null) p = mgr.getProfile(name);
        p.setServer(server); p.setPort(port);
        if (!user.isEmpty()) { p.setIsUserpw(true); p.setUsername(user); p.setPassword(pass); }

        if (DEBUG) Log.d(TAG,"Starting VPN: "+server+":"+port);
        Utility.startVpn(ctx, p);
    }

    /* ======================  STOP  ===================== */
    private void stopVpn(MethodChannel.Result result) {
        Intent svc = new Intent(context, SocksVpnService.class);
        AtomicBoolean replied = new AtomicBoolean(false);
        Handler handler = new Handler(Looper.getMainLooper());

        /* Fallback runnable إذا لم يتمّ الربط خلال المهلة */
        Runnable timeout = () -> {
            if (replied.compareAndSet(false, true)) {
                boolean ok = context.stopService(svc);
                if (ok) result.success(true);
                else    result.error("STOP","timeout",null);
            }
        };

        ServiceConnection conn = new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName n, IBinder b) {
                if (replied.compareAndSet(false, true)) {
                    IVpnService proxy = IVpnService.Stub.asInterface(b);
                    try { proxy.stop(); } catch (Exception ignore) {}
                    context.unbindService(this);
                    handler.removeCallbacks(timeout);
                    result.success(true);
                } else {
                    // الردّ أُرسل؛ لكن ما زال علينا فك الربط
                    context.unbindService(this);
                }
            }
            @Override public void onServiceDisconnected(ComponentName n) { /* لا شيء */ }
        };

        boolean bound = context.bindService(svc, conn, Context.BIND_AUTO_CREATE);
        if (!bound) {
            // لم يمكن الربط أصلاً → محاولة stopService مباشرةً
            if (replied.compareAndSet(false,true)) {
                boolean ok = context.stopService(svc);
                if (ok) result.success(true);
                else    result.error("STOP","unable-to-stop",null);
            }
            return;
        }

        /* حد أقصى 4 ثوانٍ بانتظار onServiceConnected */
        handler.postDelayed(timeout, 4000);
    }
}
