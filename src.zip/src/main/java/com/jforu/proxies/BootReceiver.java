package com.jforu.proxies;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.util.Log;

import com.jforu.proxies.util.Profile;
import com.jforu.proxies.util.ProfileManager;
import com.jforu.proxies.util.Utility;
import com.jforu.proxies.BuildConfig;     // <-- استيراد BuildConfig العادي

public class BootReceiver extends BroadcastReceiver {
    private static final String TAG   = BootReceiver.class.getSimpleName();
    private static final boolean DEBUG = BuildConfig.DEBUG;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Profile p = new ProfileManager(context).getDefault();

            if (p.autoConnect() && VpnService.prepare(context) == null) {
                if (DEBUG) Log.d(TAG, "Starting VPN service on boot");
                Utility.startVpn(context, p);
            }
        }
    }
}
